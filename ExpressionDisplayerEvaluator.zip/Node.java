// Kevin Fleishaker
// kcf9@pitt.edu
// 9962
// 9-26-13

public class Node {
    
    public char symbol;
    public Node left, right;
    
    public Node(char val)
    {
        this.symbol = val;
    }
    
    public Node(char val, Node lchild, Node rchild)
    {
        this.symbol = val;
        this.left = lchild;
        this.right = rchild;
    }
}
